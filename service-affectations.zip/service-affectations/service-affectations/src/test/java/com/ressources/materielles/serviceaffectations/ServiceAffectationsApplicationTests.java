package com.ressources.materielles.serviceaffectations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAffectationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
