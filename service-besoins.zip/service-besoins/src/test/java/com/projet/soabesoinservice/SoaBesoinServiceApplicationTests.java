package com.projet.soabesoinservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoaBesoinServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
