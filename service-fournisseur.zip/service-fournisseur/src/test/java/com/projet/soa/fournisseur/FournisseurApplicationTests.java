package com.projet.soa.fournisseur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FournisseurApplicationTests {

	@Test
	void contextLoads() {
	}

}
